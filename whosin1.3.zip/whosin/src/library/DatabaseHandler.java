package library;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.StrictMode;
import android.util.Log;
 
public class DatabaseHandler extends SQLiteOpenHelper {
 
    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;
 
    // Database Name
    private static final String DATABASE_NAME = "android_api";
 
    // Login table name
    private static final String TABLE_LOGIN = "login";
    private static final String TABLE_RE = "re";
 
    // Login Table Columns names
    private static final String KEY_AGE = "age";              // id -> age
    private static final String KEY_NAME = "name";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_LASTNAME = "lastName";              //uid -> last name
    private static final String KEY_LOCATION = "location";             //created at -> location
    private static final String KEY_IMAGE = "myImage";
 
    private static final String KEY_ID = "id";
    private static final String KEY_BUSINESS_NAME = "BusinessName";
    private static final String KEY_BUSINESS_ADRESS = "BusinessAdress";
    private static final String KEY_LOGO = "logo";
    private static final String KEY_B_EMAIL = "businessEmail";
    
    
    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
 
    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
    	//-----------User Table------------------------------------
        String CREATE_LOGIN_TABLE = "CREATE TABLE " + TABLE_LOGIN + "("
                + KEY_EMAIL + " TEXT PRIMARY KEY,"
        		+ KEY_NAME + " TEXT,"
                + KEY_LASTNAME + " TEXT,"
                + KEY_AGE + " INTEGER,"
                + KEY_LOCATION + " INTEGER,"
                + KEY_IMAGE + " BLOB" + ")";
        db.execSQL(CREATE_LOGIN_TABLE);
        //---------------Re Table------------------------------------
        String CREATE_RE_TABLE = "CREATE TABLE " + TABLE_RE + "("
        + KEY_ID + " INTEGER PRIMARY KEY,"
		+ KEY_BUSINESS_NAME + " TEXT,"
        + KEY_BUSINESS_ADRESS + " TEXT,"
        + KEY_B_EMAIL + " TEXT,"
        + KEY_LOGO + " TEXT" + ")";
        db.execSQL(CREATE_RE_TABLE);
        //---------------Image Table----------------------------------
        
    }
 
    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOGIN);
 
        // Create tables again
        onCreate(db);
    }
 
    public String getData(int i)
    {
    	String dataQuery = "SELECT  * FROM " + TABLE_LOGIN;
    	SQLiteDatabase db = this.getReadableDatabase();
    	Cursor cursor = db.rawQuery(dataQuery, null);
    	String result = "";
    	if(cursor != null)
    	{
    		if  (cursor.moveToFirst()) {
                	if(i == 0)
                	{
                		String email = cursor.getString(cursor.getColumnIndex(KEY_EMAIL));
                		String privateName = cursor.getString(cursor.getColumnIndex(KEY_NAME));
                		int age = cursor.getInt(cursor.getColumnIndex(KEY_AGE));
                		String lastName = cursor.getString(cursor.getColumnIndex(KEY_LASTNAME));                  
            //        	String picture = cursor.getString(cursor.getColumnIndex("Picture"));
                		result = ("   " + privateName + "  " + lastName + "  " + "(" +age +")"+ "\n   " + email);
                	}
                	else if(i==1)
                	{
                		String email = cursor.getString(cursor.getColumnIndex(KEY_EMAIL));
                		result = (email);
                	}                 
    		}
    	}
    	cursor.close();
    	db.close();
    	return result; 	
    }
    
    public String isCheckin()             // if user checked in return name of location
    {
    	String dataQuery = "SELECT  * FROM " + TABLE_LOGIN;
    	SQLiteDatabase db = this.getReadableDatabase();
    	Cursor cursor = db.rawQuery(dataQuery, null);
    	String result = "no";
    	if(cursor != null)
    	{
    		if  (cursor.moveToFirst()) {                 
                    int location = cursor.getInt(cursor.getColumnIndex(KEY_LOCATION));
                    if(location != 0)
                    {
                    		String loc = Integer.toString(location);
                    		String reQuery = "SELECT * FROM " + TABLE_RE + " WHERE id = " + "'" + loc + "'";
                    		cursor = db.rawQuery(reQuery, null);
                    		if  (cursor.moveToFirst()) {
                    			String re = cursor.getString(cursor.getColumnIndex(KEY_BUSINESS_NAME));
                    			result = re;
                    		}           
                    		
                    } 
    		}
    		
    	}
    	cursor.close();
    	db.close();
    	return result; 
    }
    
    
    
    /**
     * Storing user details in database
     * */
    public void addUser(String name, String email, String lastName, String age, String location, String image) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        String imageUrl = "http://www.whos-in.co.il/" + image;
        
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy); 
        
        DefaultHttpClient mHttpClient = new DefaultHttpClient();
        HttpGet mHttpGet = new HttpGet(imageUrl);
        
        	HttpResponse mHttpResponse;
			try {
				mHttpResponse = mHttpClient.execute(mHttpGet); 
        	if (mHttpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
        			HttpEntity entity = mHttpResponse.getEntity();
        			if ( entity != null) {
        				// insert to database
        				values.put(KEY_IMAGE, EntityUtils.toByteArray(entity));
        				// getContentResolver().insert(MyBaseColumn.MyTable.CONTENT_URI, values);
        			}
        		}
			}catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				values.put(KEY_IMAGE, "");
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
        values.put(KEY_NAME, name); // Name
        values.put(KEY_EMAIL, email); // Email
        values.put(KEY_LASTNAME, lastName); // Email
        values.put(KEY_AGE, age); // Created At
        values.put(KEY_LOCATION, location); // Created At
 
        // Inserting Row
        db.insert(TABLE_LOGIN, null, values);
        db.close(); // Closing database connection
    }
 
    // add re to re table
    public void addRE(int id, String name, String adress, String email, String logo)
    {
    	SQLiteDatabase db = this.getWritableDatabase();
    	ContentValues values = new ContentValues();
    	values.put(KEY_ID, id);
    	values.put(KEY_BUSINESS_NAME, name);
    	values.put(KEY_BUSINESS_ADRESS, adress);
    	values.put(KEY_B_EMAIL, email);
    	values.put(KEY_LOGO, logo);
    	db.insert(TABLE_RE, null, values);
    	db.close();
    }
    
    public byte[] getImage()
    {
    	byte[] bb; 
    	String dataQuery = "SELECT  * FROM " + TABLE_LOGIN;
    	SQLiteDatabase db = this.getReadableDatabase();
    	Cursor cursor = db.rawQuery(dataQuery, null);
    	cursor.moveToFirst();
    	Log.d("error sql", "got to getImage");
    	bb = cursor.getBlob(cursor.getColumnIndex(KEY_IMAGE));
    	db.close();
    	cursor.close();
    	return bb;
    }
    
    public int nameToId(String name)
    {
    	int id = -1;
    	SQLiteDatabase db = this.getWritableDatabase();
    	String query = "SELECT " + KEY_ID + " FROM " + TABLE_RE + " WHERE " + KEY_BUSINESS_NAME + " = " + "'" + name + "'"; 
    	Cursor cursor = db.rawQuery(query, null);
    	if(cursor.moveToFirst())
    	{
    		id = cursor.getInt(cursor.getColumnIndex(KEY_ID));
    	}
    	cursor.close();
    	db.close();
    	return id;
    }
    
    //update location - check if works
    public void update_location(int id)
    {
    	SQLiteDatabase db = this.getWritableDatabase();
    	ContentValues values = new ContentValues();
    	values.put(KEY_LOCATION, id);
    	db.insert(TABLE_LOGIN, null, values);
    	db.close();
    }
    /**
     * Getting user data from database
     * */
    public HashMap<String, String> getUserDetails(){
        HashMap<String,String> user = new HashMap<String,String>();
        String selectQuery = "SELECT  * FROM " + TABLE_LOGIN;
 
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        // Move to first row
        cursor.moveToFirst();
        if(cursor.getCount() > 0){
            user.put("name", cursor.getString(1));
            user.put("email", cursor.getString(2));
            user.put("lastName", cursor.getString(3));
            user.put("age", cursor.getString(4));
            user.put("location", cursor.getString(5));
        }
        cursor.close();
        db.close();
        // return user
        return user;
    }
 
    /**
     * Getting user login status
     * return true if rows are there in table
     * */
    public int getRowCount() {
        String countQuery = "SELECT  * FROM " + TABLE_LOGIN;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int rowCount = cursor.getCount();
        db.close();
        cursor.close();
 
        // return row count
        return rowCount;
    }
    
    
    
    /**
     * Re crate database
     * Delete all tables and create them again
     * */
    public void resetTables(){
        SQLiteDatabase db = this.getWritableDatabase();
        // Delete All Rows
        db.delete(TABLE_LOGIN, null, null);

        db.close();
    }
 
    public void resetList(){
    	SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_RE, null, null);
        db.close();
    }
}