package com.whosin;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
 
import library.DatabaseHandler;
import library.UserFunctions;
 
public class DashboardActivity extends Activity {
    UserFunctions userFunctions;
    Button btnLogout;
    Button btnReList;
    Button btnCheckOut;
    TextView user_data;
    TextView user_location;
    ImageView user_image;
 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
 
        /**
         * Dashboard Screen for the application
         * */
         //Check login status in database
        userFunctions = new UserFunctions();
        if(userFunctions.isUserLoggedIn(getApplicationContext())){
       // user already logged in show databoard
        	// extract details from db and add to string to show
        
        	setContentView(R.layout.dashboard);
            user_data = (TextView) findViewById(R.id.userD);
            user_location = (TextView) findViewById(R.id.uLocation);
            btnReList = (Button) findViewById(R.id.btnReList);
            btnCheckOut = (Button) findViewById(R.id.btnCheckOut);
            user_image = (ImageView) findViewById(R.id.imageView1);
            DatabaseHandler db = new DatabaseHandler(getApplicationContext());
            
            
            Log.d("done with"," local");
          
            Intent i = getIntent();
            // getting attached intent data
            String place = i.getStringExtra("place");
            int flag =0;
            if(place != null)
            {
            	int id = db.nameToId(place);
            	if(id != -1)
            	{
			        userFunctions.DBcheckInOut(getApplicationContext(), id);
			        flag = 1;
            	}
			    else Log.d("error", "failed to convert from name to string");
            }else Log.d("error", "place = null");
            // displaying selected product name
         //   txtProduct.setText(product);
            
           // String local = db.isCheckin();
            if(flag != 0){
            //	Log.d("inside"," local != no");
            	btnReList.setVisibility(View.INVISIBLE);
            	btnCheckOut.setVisibility(View.VISIBLE);
            	place = "   You are in: " + place;
            	user_location.setText(place);
            }else
            {
            //	user_location.setText(local);
            	Log.d("inside"," local == no");
            	btnReList.setVisibility(View.VISIBLE);
            	btnCheckOut.setVisibility(View.INVISIBLE);
            	user_location.setVisibility(View.INVISIBLE);
            }  
                    
            String dataS = db.getData(0);
            if(dataS != "")
            	{
            		user_data.setText(dataS);
            		byte[] bb = db.getImage();
            		user_image.setImageBitmap(BitmapFactory.decodeByteArray(bb, 0, bb.length));
            	}
            
            btnCheckOut.setOnClickListener(new View.OnClickListener() {
 
                public void onClick(View arg0) {
                    // TODO Auto-generated method stub
                    
                	userFunctions.DBcheckInOut(getApplicationContext(), 0);
                    Intent back = new Intent(getApplicationContext(), DashboardActivity.class);
                    back.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    back.putExtra("place", "");
                    startActivity(back);
                    // Closing dashboard screen
                    finish();
                }
            });
            
            
            btnReList.setOnClickListener(new View.OnClickListener() {
 
                public void onClick(View arg0) {
                    // TODO Auto-generated method stub
                    
                    Intent reList = new Intent(getApplicationContext(), ReListActivity.class);
                    reList.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(reList);
                    // Closing dashboard screen
                    finish();
                }
            });
            
            btnLogout = (Button) findViewById(R.id.btnLogout);
 
            btnLogout.setOnClickListener(new View.OnClickListener() {
 
                public void onClick(View arg0) {
                    // TODO Auto-generated method stub
                	userFunctions.DBcheckInOut(getApplicationContext(), 0);
                	userFunctions.logoutUser(getApplicationContext());
                    
                    Intent login = new Intent(getApplicationContext(), LoginActivity.class);
                    login.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(login);
                    // Closing dashboard screen
                    finish();
                }
            });
 
        }else{
            // user is not logged in show login screen
            Intent login = new Intent(getApplicationContext(), LoginActivity.class);
            login.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(login);
            // Closing dashboard screen
            finish();
        }
    }
}