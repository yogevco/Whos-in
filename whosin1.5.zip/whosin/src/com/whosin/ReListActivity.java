package com.whosin;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import library.DatabaseHandler;
import library.UserFunctions;

public class ReListActivity extends ListActivity{
	
	UserFunctions userFunctions;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
 
        userFunctions = new UserFunctions();
        DatabaseHandler db = new DatabaseHandler(getApplicationContext());
        
        JSONObject json;
    	json = userFunctions.reList();
    	try 
    	{
    		if (json.getString("success") != null)
    		{
    			String res = json.getString("success");
    			if(Integer.parseInt(res) == 1)              
    			{
    				String s = json.getString("rows");
    				int rows = Integer.parseInt(s);
    				String[] re = new String[rows+1];
    				JSONObject jArray[] = new JSONObject[rows];
    				db.resetList();
    				for(int i = 0; i<rows; i++)
    				{
    					s = Integer.toString(i+1);
    					jArray[i] = json.getJSONObject(s);
    					db.addRE(Integer.parseInt(jArray[i].getString("id")), jArray[i].getString("name"),jArray[i].getString("adress"), jArray[i].getString("email"), jArray[i].getString("logo"));
    					re[i] = jArray[i].getString("name") + ", " + jArray[i].getString("adress");
    				}
    				re[rows] = "go back";
    				this.setListAdapter(new ArrayAdapter<String>(this, R.layout.list_item, R.id.label, re));
    				ListView lv = getListView();
    				
    				lv.setOnItemClickListener(new OnItemClickListener() {
    			          public void onItemClick(AdapterView<?> parent, View view,
    			              int position, long id) {
    			 
    			              // selected item
    			              String place = ((TextView) view).getText().toString();
    			              Intent i = new Intent(getApplicationContext(), DashboardActivity.class);
    			              // sending data to new activity
    			              String[] ans = place.split("\\,");
    			              place = ans[0];
    			              if(place == "go back")
    			            	  i.putExtra("place", "");
    			              else i.putExtra("place", place);
    			              startActivity(i);
    			              finish();
    			 
    			          }
    			        });
    			}
            }
        } 
    	catch (JSONException e) {
    		e.printStackTrace();} 
    }
}
