package com.whosin;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import library.DatabaseHandler;
import library.UserFunctions;

public class ReListActivity extends ListActivity{
	
	UserFunctions userFunctions;
	 GPSTracker gps;
	 double[] position;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
 
        userFunctions = new UserFunctions();
        DatabaseHandler db = new DatabaseHandler(getApplicationContext());
        position = new double[2];
        gps = new GPSTracker(ReListActivity.this);
        Log.d("RE", "created the obj");
        // check if GPS enabled
        if(gps.canGetLocation())
        {
            double latitude = gps.getLatitude();
            double longitude = gps.getLongitude();
            position[0] = latitude;
            position[1] = longitude;
        }else
        	{
            // can't get location
            // GPS or Network is not enabled
            // Ask user to enable GPS/network in settings
            gps.showSettingsAlert();
            
        	} 
        Log.d("re", "location: " + Double.toString(position[0]) + " , " + Double.toString(position[1]));    
        
        JSONObject json;
    	json = userFunctions.reList();
    	try 
    	{
    		if (json.getString("success") != null)
    		{
    			String res = json.getString("success");
    			if(Integer.parseInt(res) == 1)              
    			{
    				String s = json.getString("rows");
    				int rows = Integer.parseInt(s);
    				int near =0;
    				int[] c = new int[rows];
    				JSONObject jArray[] = new JSONObject[rows];
    				db.resetList();
    				double[] place = new double[2];
    				for(int i = 0; i<rows; i++)
    				{
    					s = Integer.toString(i+1);
    					jArray[i] = json.getJSONObject(s);
    					place[0] = Double.parseDouble(jArray[i].getString("lat"));
    					place[1] = Double.parseDouble(jArray[i].getString("lng"));
    					Log.d("re", "position: " + Double.toString(place[0]) + " , " + Double.toString(place[1]));
    					if(inRange(position, place)){
    						near++;
    						c[i]=1;
    						}
    					else c[i]=0;
    				}
    				String[] re = new String[near+1];
    				Log.d("re", "near: " + near);
    				int counter = 0;
    				for(int i=0; i<rows; i++)
    				{
    					if(c[i] == 1)
    					{
    						db.addRE(Integer.parseInt(jArray[i].getString("id")), jArray[i].getString("name"),jArray[i].getString("adress"), jArray[i].getString("email"), jArray[i].getString("logo"));
							re[counter] = jArray[i].getString("name") + ", " + jArray[i].getString("adress");
							counter++;
    					}
    				}
    				
    				re[near] = "go back";
    				this.setListAdapter(new ArrayAdapter<String>(this, R.layout.list_item, R.id.label, re));
    				ListView lv = getListView();
    				
    				lv.setOnItemClickListener(new OnItemClickListener() {
    			          public void onItemClick(AdapterView<?> parent, View view,
    			              int position, long id) {
    			 
    			              // selected item
    			              String place = ((TextView) view).getText().toString();
    			              Intent i = new Intent(getApplicationContext(), DashboardActivity.class);
    			              // sending data to new activity
    			              String[] ans = place.split("\\,");
    			              place = ans[0];
    			              if(place == "go back")
    			            	  i.putExtra("place", "");
    			              else i.putExtra("place", place);
    			              startActivity(i);
    			              finish();
    			 
    			          }
    			        });
    			}
            }
        } 
    	catch (JSONException e) {
    		e.printStackTrace();} 
    }
	
	public boolean inRange(double[] position, double[] place)
	{
		double far = 0.00001;  // distence from place
		if(position[0]+far < place[0])
			return false;
		if(position[0]-far > place[0])
			return false;
		if(position[1]+far < place[1])
			return false;
		if(position[1]-far > place[1])
			return false;
		return true;
	}
	
}
