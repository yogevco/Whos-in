package com.whosin;

import org.json.JSONException;
import org.json.JSONObject;

import library.DatabaseHandler;
import library.UserFunctions;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class WhosInActivity extends Activity {

 LinearLayout myGallery;
 UserFunctions userFunctions;
 DatabaseHandler db;
 Button btnBack;
 
 //--------------------------------------------------------
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.whosin);
        
        userFunctions = new UserFunctions();
        db = new DatabaseHandler(getApplicationContext());
        Intent i = getIntent();
        int id = i.getIntExtra("who", 0);
        userFunctions = new UserFunctions();
        myGallery = (LinearLayout)findViewById(R.id.mygallery);
        btnBack = (Button) findViewById(R.id.btnBack);
        
        String path = "http://www.whos-in.co.il/";
        
        Toast.makeText(getApplicationContext(), path, Toast.LENGTH_LONG).show();
        JSONObject json;
        json = userFunctions.getWho(id);
        try{
    	   if(json.getString("success") != null)
    	    {
    		   String res = json.getString("success");
               if(Integer.parseInt(res) == 1)
               {
            	    String s = json.getString("rows");
            	    String pic;
            	    byte[] bb;
   					int rows = Integer.parseInt(s);
   					JSONObject jArray[] = new JSONObject[rows];
   					for(int j = 0; j<rows; j++)
    				{
    					s = Integer.toString(j+1);
    					jArray[j] = json.getJSONObject(s);
    					pic = jArray[j].getString("image");
    					bb = db.getImageBlob(pic);
    					//------------
    					 LinearLayout layout = new LinearLayout(getApplicationContext());
    				     layout.setLayoutParams(new LayoutParams(250, 250));
    				     layout.setGravity(Gravity.CENTER);
    				     
    				     ImageView imageView = new ImageView(getApplicationContext());
    				     imageView.setLayoutParams(new LayoutParams(220, 220));
    				     imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
    				     imageView.setImageBitmap(BitmapFactory.decodeByteArray(bb, 0, bb.length));
    				     
    				     layout.addView(imageView);
    					//----------
    					myGallery.addView(layout);
    				}
               }
        	}
       }catch (JSONException e) {
            e.printStackTrace();
        }  
       btnBack.setOnClickListener(new View.OnClickListener() {
    	   
           public void onClick(View arg0) {
               // TODO Auto-generated method stub
        	   Intent i = getIntent();
               int id = i.getIntExtra("who", 0);
               Intent back = new Intent(getApplicationContext(), DashboardActivity.class);
               back.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
               back.putExtra("id", id);
               startActivity(back);
               // Closing dashboard screen
               finish();
           }
       }); 
    }   
}
