package com.whosin;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.ActionBar.LayoutParams;
import android.app.Activity;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
 
import library.DatabaseHandler;
import library.UserFunctions;
 
public class DashboardActivity extends Activity {
    UserFunctions userFunctions;
    Button btnLogout;
    Button btnReList;
    Button btnCheckOut;
    Button btnWhosIn;
    TextView user_data;
    TextView user_location;
    ImageView user_image;
 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
 
        /**
         * Dashboard Screen for the application
         * */
         //Check login status in database
        userFunctions = new UserFunctions();
        if(userFunctions.isUserLoggedIn(getApplicationContext())){
       // user already logged in show databoard
        	// extract details from db and add to string to show
        
        	setContentView(R.layout.dashboard);
            user_data = (TextView) findViewById(R.id.userD);
            user_location = (TextView) findViewById(R.id.uLocation);
            btnReList = (Button) findViewById(R.id.btnReList);
            btnCheckOut = (Button) findViewById(R.id.btnCheckOut);
            btnWhosIn = (Button) findViewById(R.id.btnWhosIn);
            user_image = (ImageView) findViewById(R.id.imageView1);
            DatabaseHandler db = new DatabaseHandler(getApplicationContext());
                      
            Intent i = getIntent();
            // getting attached intent data
            String place = i.getStringExtra("place");
            int reId = i.getIntExtra("id", 0);
            int flag =0, id;
            
            if(reId != 0)                          // if was back from WhosInActivity
            {	
            	place = db.idToName(reId);
		        flag = 1;
            }
            else if(place != null)                // if back from ReListActivity
            {
            	id = db.nameToId(place);
            	if(id != -1)
            	{
			        userFunctions.DBcheckInOut(getApplicationContext(), id);    //check in to place
			        flag = 1;
			        i.putExtra("id", id);
            	}			    
            }

            if(flag != 0){                                    
            //	user checked in           	
            	btnReList.setVisibility(View.INVISIBLE);
            	btnCheckOut.setVisibility(View.VISIBLE);
            	btnWhosIn.setVisibility(View.VISIBLE);
            	place = "   You are in: " + place + "  ";
            	user_location.setText(place);
            }else
            {
            //	user did not check in
            	btnReList.setVisibility(View.VISIBLE);
            	btnCheckOut.setVisibility(View.INVISIBLE);
            	user_location.setVisibility(View.INVISIBLE);
            	btnWhosIn.setVisibility(View.INVISIBLE);
            }  
                    
            String dataS = db.getData(0);
            if(dataS != "")    //setting up user's data and picture
            	{
            		user_data.setText(dataS);
            		byte[] bb = db.getImage();
            		user_image.setImageBitmap(BitmapFactory.decodeByteArray(bb, 0, bb.length));
            	}
            
            btnCheckOut.setOnClickListener(new View.OnClickListener() { 
            	// if user want to check out
                public void onClick(View arg0) {
                    // TODO Auto-generated method stub
                    
                	userFunctions.DBcheckInOut(getApplicationContext(), 0);
                    Intent back = new Intent(getApplicationContext(), DashboardActivity.class);
                    back.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    back.putExtra("place", "");
                    startActivity(back);
                    finish();
                }
            });
            
            btnWhosIn.setOnClickListener(new View.OnClickListener() {
            	//if user want to know whos in 
                public void onClick(View arg0) {
                    // TODO Auto-generated method stub
                    
                	Intent i = getIntent();
                	int id = i.getIntExtra("id", 0);   //passing the places id                   
                	Intent whosin = new Intent(getApplicationContext(), WhosInActivity.class);
                    whosin.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    whosin.putExtra("who", id);
                    startActivity(whosin);
                    finish();
                }
            });
            
            btnReList.setOnClickListener(new View.OnClickListener() {
            	//if user want to check in
                public void onClick(View arg0) {
                    // TODO Auto-generated method stub
                    
                    Intent reList = new Intent(getApplicationContext(), ReListActivity.class);
                    reList.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(reList);
                    finish();
                }
            });
            
            btnLogout = (Button) findViewById(R.id.btnLogout);
 
            btnLogout.setOnClickListener(new View.OnClickListener() {
            	//if user wants to logout
                public void onClick(View arg0) {
                    // TODO Auto-generated method stub
                	userFunctions.DBcheckInOut(getApplicationContext(), 0);
                	userFunctions.logoutUser(getApplicationContext());
                    
                    Intent login = new Intent(getApplicationContext(), LoginActivity.class);
                    login.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(login);
                    finish();
                }
            });
 
        }else{
            // user is not logged in show login screen
            Intent login = new Intent(getApplicationContext(), LoginActivity.class);
            login.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(login);
            finish();
        }
    }
}