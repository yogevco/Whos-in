package com.whosin;

import org.json.JSONException;
import org.json.JSONObject;

import com.whosin.IntentIntegrator;
import com.whosin.ReListActivity;
import com.whosin.R;

import android.app.Activity;
import android.app.ListActivity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import library.DatabaseHandler;
import library.UserFunctions;

public class ReListActivity extends Activity{
	
	UserFunctions userFunctions;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.relist);
 
        
    //    IntentIntegrator integrator = new IntentIntegrator(ReListActivity.this);
    //    integrator.initiateScan();
        
        try {
            Button scanner = (Button)findViewById(R.id.scanner);
            scanner.setOnClickListener(new OnClickListener() {
                
                public void onClick(View v) {
                    Intent intent = new Intent("com.google.zxing.client.android.SCAN");
                    intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
                    startActivityForResult(intent, 0);
                }
 
            });
        } catch (ActivityNotFoundException anfe) {
            Log.e("onCreate", "Scanner Not Found", anfe);
        }                         
	}

    
	
	
public void onActivityResult(int requestCode, int resultCode, Intent intent) {
           	
    	if (requestCode == 0) {
            if (resultCode == RESULT_OK) {
                String contents = intent.getStringExtra("SCAN_RESULT");
                String[] split = contents.split(";");
                int QRid = Integer.parseInt(split[0]);
                
                userFunctions = new UserFunctions();
                DatabaseHandler db = new DatabaseHandler(getApplicationContext()); 
                JSONObject json;
            	json = userFunctions.reList();
                try 
            	{
            		if (json.getString("success") != null)
            		{
            			String res = json.getString("success");
            			if(Integer.parseInt(res) == 1)              
            			{
            				String s = json.getString("rows");
            				int rows = Integer.parseInt(s);
            				JSONObject jArray[] = new JSONObject[rows];
            				db.resetList();
            				for(int i = 0; i<rows; i++)
            				{
            					s = Integer.toString(i+1);
            					jArray[i] = json.getJSONObject(s);
            					if(QRid == Integer.parseInt(jArray[i].getString("id")))
            					{
            						db.addRE(Integer.parseInt(jArray[i].getString("id")), jArray[i].getString("name"),jArray[i].getString("adress"), jArray[i].getString("email"), jArray[i].getString("logo"));
            						String place = jArray[i].getString("name");
            						Intent t = new Intent(getApplicationContext(), DashboardActivity.class); 
            						t.putExtra("place", place);
            						startActivity(t);
           			              	finish();
            					}
            			}
                    }
                } }
            	catch (JSONException e) {
            		e.printStackTrace();}

            } else if (resultCode == RESULT_CANCELED) {
                // Handle cancel
                Toast toast = Toast.makeText(this, "Scan was Cancelled!", Toast.LENGTH_LONG);
                toast.setGravity(Gravity.TOP, 25, 400);
                toast.show();
                
            }
    	}
	} 	
}